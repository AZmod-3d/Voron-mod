Thank you for choosing AZ mod ：）
感谢你选择AZ的模组！：）
                                       BOM
M3*14                  *2
M3*16                  *2
M3*4*5NUT        *2

FAQ*
Please refer to the folder's images for installation instructions.
安装说明请看文件夹中的图片!

If you have any suggestions or questions, please contact me!
如果你有任何问题或者建议,请联系我！

contact information：
联系方式：
————————————————————————
Discord：https://discord.gg/TGkTASn9A7
bilbili：https://space.bilibili.com/263877194
QQ群组：1029501717
————————————————————————